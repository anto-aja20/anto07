const anime = () => { 
	return `       
	Anime Romance dimana Heroine nya awalnya benci kemudian jatuh cinta
°Fuuka
°Masamune's Revenge
°Sousei no Onmyouji
°Oda Nobuna no Yabou
°Kaze no Stigma
°Btooom!
°Tonari no Kaibutsu-kun
°Akame ga Kill
°Kaichou wa Maid-sama!
°Nisekoi
____________________________
Anime dimana MC ke Isekai dan mendapatkan kekuatan OP
°Isekai wa Smartphone to Tomo ni
°Isekai Maou to Shokan Shoujo no Dorei Majutsu
°Arifureta Shokugyo de Sekai Saikyou
°Maou-sama, Retry!
°Hataraku Maou-sama
°Drifter
°Yojou Senki
°Tensei Shitara Slime Datta Ken
°No Game No Life
____________________________
Top Anime Romance/Action
°Beatless
°Kishuku Gakkou no Juliet
°Devil Line
°Toaru Hikuushi e no Koiuta
°Shuumatsu Nani Shitemasu ka? Isogashii Desu ka? Sukutte Moratte Ii desu ka?
____________________________
Anime dimana MC OP tidak mengetahui kekuatan sebenarnya
°Dakara Boku wa, H ga Dekinai
°Tokyo Ravens
°Kore wa Zombie desu ka?
°Maoyuu Maou Yuusha
°Blood Lad
°Musaigen no Phantom World
°Witch Craft Works
____________________________
Anime dimana MC OP tapi tidak dapat mengendalikan kekuatannya
°Sousei no Onmyouji
°Bungo Stray Dogs
°Owari no Seraph
°Kyoukai no Kanata
•Mushibugyo
____________________________
Best Anime Romance 
•Love Lab
°Noucome
°Inou-Battle wa Nichijou-Kei no Naka de
°Boku wa Tomodachi ga Sukunai
°Kono Bijutsubu ni wa Mondai ga Aru!
°Just Because!
°Mayo Chiki!
°Mikakunin de Shinkoukei
°Sankarea
°Oda
°Seiren
°3D kanojo
______________________________
Top anime MC kalem/badass
°Amnesia
°Angel Beats!
°Tokyo Ghoul
°Darling in the FranXX
°Golden Time
_____________
.Top 10 Harem dan MC over power
°Maji de Watashi Ni Koi Shinasai!
°Hagure Yuusha no Aesthetica
°Busou Shoujo Machiavellianism
°Hidan no Aria
°Seiken Tsukai no World Break
°Hundred
°Masou Gakuen HXH
°Highschool DxD
°Seikon no Qwaser
°Inou-Battle Nichijou-Kei no Naka de
____________________________
Top Harem MC OP
°IS: Infinite Stratos
°Campione!
°Kore wa Zombie Desu ka?
°Trinity Seven
°Yuragi-sou no Yuuna-san
•Sin: Nanatsu no Taizai
•Neon Genesis Evangelion
•Hello World
•Recently, My sister is unusual
•Vampire Knight
____________________________
Top Anime MC ngebangkitkan kekuatannya
°Hitsugi no Chaika
°Tsubasa Chronicle
°Fate/Stay Night
°Seiken no Blacksmith
°Absolute Duo
°Dakara Boku wa, H ga Dekinai
°Mahou Sensou
____________________________
Top Anime with anti sosial & OP MC
°Goblin Slayer
°No Game No Life
°Grisaia no Kajitsu
°Jormungand
°Classroom of the Elite
°Saiki Kusou no Psi Nan
____________________________
Top anime MC badas
°Drifters
•Kara no Kyoukai
•Kino no Tabi
°Darker than Black
°Grisaia Series
°Fate/Zero
____________________________
Top Anime MC pura² lemah padahal kuat
°Blood Lad
°Rokudenashi Majutsu Koushitsu
°Saiki Kusou no Psi Nan
°Classroom of the Elite
____________________________
Top anime with OP MC (2019)
°Isekai Cheat Magician
°Arifureta Shokugyo Sekai ni Saikyou
°Maou-sama, Retry!
°Katsute Kami Datta Kemono-tachi e
°Toaru Kagaku no Accelerator
°Kenja no Mago
°Vinland Saga
°Tate no Yuusha no Nariagari
°Dr. Stone
____________________________
Top anime MC abadi
°Itsuka Tenma no Kuro Usagi
°UQ Holder
°Renai Boukun
•Kuroshitsuji
°Sayonara no Asa
°Re:Zero Kara Hajimeru Isekai Seikatsu
____________________________
Top anime dimana MC dikhianati dan jatuh ke jalan gelap
°Arifureta Shokugyo Sekai ni Saikyou
°Guilty Crown
°Akame ga Kill
°Zetsuen no Tempest
°Ao no Excorcist
°Densetsu no Yuusha no Densetsu
•91 Days
°Tate no Yuusha no Nariagari
•Shinsekai Yori
°Btooom!
•Mawaru Penguindrum
____________________________
Top anime MC terlihat malas tapi OV/badass
°Densetsu no Yuusha no Densetsu
°Rokudenashi Majutsu Koushitsu
°Zetsuen no Tempest
°Nejimaki Seirei Senki: Tenkyou no Alderamin
°Gate
°Hyouka
°Gintama
____________________________
Top Anime yang MC-nya adalah legenda pensiunan yang kembali lagi
°Accel World
°Noragami
°Shuumatsu Nani Shitemasu ka?
•Yuushibu
°Rokudenashi Majutsu Koushitsu
°Densetsu no Yuusha no Densetsu
°Hataraku Maou-sama
°Violet Evergarden
°Hagure Yuusha no Aesthetica
____________________________
Top Anime dengan MC memiliki masa lalu yang gelap
°Zankyou no Terror
°Black Bullet
°Jigoku Shoujo
°Owari no Seraph
•91 Days
°Classroom of the Elite
°Noragami
____________________________
Top anime dengan MC yang memiliki kekuatan khusus
°Dakara Boku wa, H ga Dekinai
°Yuragi-Sou no Yuuna-san
°Inu X Boku SS
°Charlotte
____________________________
Top Anime Cinta Obsesi 
°Amagami SS
°Aho Girl
•Kono Bijutsubu
°Haiyore! Nyaruko-san
°Shuffle!
°Gekkan Shoujo Nozaki-kun
°Renai Boukun
°Mirai Nikki
°Kawaikereba Hentai demo Suki ni Natte Kuremasu ka?
____________________________
Top anime romantis-komedi
•Net-juu no Susume
°Mikakunin de Shinkoukei
°Chuunibyou demo Koi ga Shitai!
°Servant x Service
°Masamune-kun's Revenge
•Gamers!
°Nisekoi
____________________________
Top Anime dimana MC memiliki kekuatan Hewan Legendaris
°Seikoku no Dragonar
°Bungo Stray Dogs
°High school DxD
°Owari no Seraph
____________________________
Top Anime dimana MC OP dan tidak ada yang mengetahui
°Chrome Shelled Regios
•Tokyo Majin Gakuen Kenpuchou
°Quanzhi Fashi
°Rokudenashi Majutsu Koushitsu
°Witch Craft Works
°Mahouka Koukou no Rettousei
°Rakudai Kishi no Cavalry
____________________________
Top Anime dengan MC OP
•Phantom: Requiem for the Phantom
°Divine Gate
°Hitsugi no Chaika
°Code: Breaker
•Kiznaiver
°Ansatsu koushitsu
•Kara no Kyoukai
____________________________
Top Anime dimana MC nya Jenius/Cerdas/Ahli siasat
°Nejimaki Seirei Senki: Tenkyou no Alderamin
°Hyouka
°Dr. Stone
°Classroom of the Elite
°No Game No Life
°Death Note
____________________________
Anime dimana MC adalah murid pindahan yang OP
°Hundred
°Code: Breaker
•Tokyo Majin Gakuen Kenpuchou
°Chrome Shelled Regios
°Kill la Kill
°Mahouka Koukou no Rettousei
____________________________

anime Isekai (2019)
°Tsuujou Kougeki ga Zentai Kougeki de Ni-kai Kougeki no - Okaasan wa Suki Desu ka?
°Arifureta Shokugyo de Sekai Saikyou
°Kenja no Mago
°Maou-sama, Retry!
°Watashi, Nouryoku wa Heikinchi de tte Yo ne!
°Mairimashita! Iruma-kun
°Honzuki no Gekokujou: Shisho ni Naru Tame ni Shudan wo
°Choujin Koukousei-tachi wa Isekai demo Yoyuu de Ikinuku you Desu!
°Shinchou Yuusha: Kono Yuusha ga Ore Tueee Kuseni Shinchou Sugiru`
}
exports.anime = anime